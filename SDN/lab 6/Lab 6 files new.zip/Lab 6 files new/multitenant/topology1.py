from mininet.topo import Topo
from mininet.net import Mininet
from mininet.log import setLogLevel
from mininet.cli import CLI
from mininet.node import RemoteController
from time import sleep
from mininet.link import Intf


CONTROLLER_IP = "192.168.122.1"



class SingleSwitchTopo(Topo):
    "Single switch connected to n hosts."
    def build(self):
        s1 = self.addSwitch('s1', dpid='100')
	#tenant1
        a1 = self.addHost('a1', mac="00:00:00:00:00:01", ip="10.1.1.1/24")
        a2 = self.addHost('a2', mac="00:00:00:00:00:02", ip="10.1.1.2/24")
	#tenant2
        b1 = self.addHost('b1', mac="00:00:00:00:10:01", ip="172.16.1.1/24")
        b2 = self.addHost('b2', mac="00:00:00:00:10:02", ip="172.16.1.2/24")
	#tenant3
        c1 = self.addHost('c1', mac="00:00:00:00:20:01", ip="10.2.1.1/24")
        c2 = self.addHost('c2', mac="00:00:00:00:20:02", ip="10.2.1.2/24")
        self.addLink(a1, s1)
        self.addLink(a2, s1)
        self.addLink(b1, s1)
        self.addLink(b2, s1)
        self.addLink(c1, s1)
        self.addLink(c2, s1)

if __name__ == '__main__':
    setLogLevel('info')
    topo = SingleSwitchTopo()
    #change the controller IP here
    c1 = RemoteController('c1', ip=CONTROLLER_IP)
    net = Mininet(topo=topo, controller=c1)
    net.start()
    sleep(5)
    net.pingAll()
    CLI(net)
    net.stop()


'''
sudo ovs-vsctl add-port s1 vxlan1 -- set interface vxlan1 type=vxlan options:remote_ip=192.168.122.149 options:key=flow ofport_request=10
sudo ovs-vsctl add-port s1 vi0 -- set Interface vi0 type=internal
sudo ifconfig vi0 10.250.204.1/24 up
'''
