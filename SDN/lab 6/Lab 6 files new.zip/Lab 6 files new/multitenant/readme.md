

sudo ovs-ofctl add-flows s1 flows.txt 

sudo ovs-ofctl add-flows s2 flows.txt 
